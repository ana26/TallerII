
package ejecutables;


public class ejecutararchivo {

    public  static void ejecutararchivo2(){
        Runtime aplicacion=Runtime.getRuntime();
        try{
            aplicacion.exec("cmd /c start "+ "programa.bat");
        }
        catch(Exception e){}
    }
public static void main(String []args){
    ejecutararchivo2();
}
}

